<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<h2 class="text-center"><?php echo e(__('messages.my_tbots')); ?></h2>

<a href="javascript:void(0);" class="btn btn-success float-end open-form" data-action="add" data-id="0" data-bs-toggle="modal" data-bs-target="#tgBotModal"><?php echo e(__('messages.add_tbot')); ?></a>
<div class="clearfix"></div>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('info')): ?>
    <div class="alert alert-info">
        <?php echo e(session('info')); ?>

    </div>
<?php endif; ?>

    <table class="table table-hover">
        <thead>
            <tr>
                <th style="width:50px;">#</th>
                <th style="width:200px;"><?php echo e(__('messages.tbot_name')); ?></th>
                <th style="width:200px;"><?php echo e(__('messages.tbot_username')); ?></th>
                <th><?php echo e(__('messages.tbot_token')); ?></th>
                <th  style="width:200px;"><?php echo e(__('messages.edit')); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php
            $i=0;
            ?>
             <?php $__currentLoopData = $bots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $i++;
                ?>
                <tr>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($bot->name); ?></td>
                    <td><?php echo e($bot->username); ?></td>
                    <td><?php echo e($bot->token); ?></td>
                    <td><a href="javascript:void(0);" class="open-form" data-action="edit" data-id="<?php echo e($bot->id); ?>" data-bs-toggle="modal" data-bs-target="#tgBotModal"><?php echo e(__('messages.edit')); ?></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
        <?php echo e($bots->links('pagination::bootstrap-5')); ?>

</div>

<!-- Modal -->
<div class="modal fade" id="tgBotModal" tabindex="-1" aria-labelledby="tgBotModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="tgBotModalLabel">Form</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        opening...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
$(document).ready(function(){
    $('.open-form').on('click', function() {
        let id = $(this).data('id');
        let action = $(this).data('action');
        $.ajax({
            url: '/form/'+action+'/'+id,
            method: 'get',
            success:function(data) {
                $('#tgBotModal .modal-body').html(data);
            }
        
        });
    });
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.telegrambot', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/jobresum/domains/jobresume.uz/public_html/bot/resources/views/telegrambot/index.blade.php ENDPATH**/ ?>