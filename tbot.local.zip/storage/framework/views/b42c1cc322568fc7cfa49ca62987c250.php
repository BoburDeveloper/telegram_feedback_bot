<?php $__env->startSection('content'); ?>

<h2 class="text-center"><?php echo e(__('messages.'.$action.'_tbot')); ?></h2>

<div class="container-fluid">
    
    <form action="<?php echo e($_SERVER['REQUEST_URI']); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        
        <div class="form-group">
            <label for="tbot_name"><?php echo e(__('messages.tbot_name')); ?></label>
            <input type="text" class="form-control" name="tbot[name]" value="<?php echo e(isset($bot->name) ? $bot->name : null); ?>" />
        </div>
        <div class="form-group">
            <label for="tbot_username"><?php echo e(__('messages.tbot_username')); ?></label>
            <input type="text" class="form-control" name="tbot[username]" value="<?php echo e(isset($bot->username) ? $bot->username : null); ?>" />
        </div>
        <div class="form-group">
            <label for="tbot_token"><?php echo e(__('messages.tbot_token')); ?></label>
            <input type="text" class="form-control" name="tbot[token]" value="<?php echo e(isset($bot->token) ? $bot->token : null); ?>" />
        </div>
        <div class="form-group text-end">
            <button type="submit" class="btn btn-<?php echo e($action=='add' ? 'success' : 'primary'); ?>"><?php echo e(__('messages.save')); ?></button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.telegrambot', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/jobresum/domains/jobresume.uz/public_html/bot/resources/views/telegrambot/form.blade.php ENDPATH**/ ?>