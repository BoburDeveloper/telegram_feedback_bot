<!DOCTYPE html>
<html lang="en">
<head>
    <title></title>
    <link rel="stylesheet" href="<?php echo e(asset($asset_theme.'bootstrap-ui/css/bootstrap.min.css')); ?>"/>
    <script type="text/javascript" src="<?php echo e(asset($asset_theme.'jquery/jquery.min.js')); ?>"></script>
</head>
<body>

<?php echo $__env->yieldContent('content'); ?>

<footer></footer>
<script type="text/javascript" src="<?php echo e(asset($asset_theme.'bootstrap-ui/js/bootstrap.min.js')); ?>"></script>
</body>
</html><?php /**PATH /home/jobresum/domains/jobresume.uz/public_html/bot/resources/views/layouts/telegrambot.blade.php ENDPATH**/ ?>