<h2>📥 Yangi Telegram xabari</h2>

<p><strong>Ismi:</strong> <?php echo e($firstName); ?></p>
<p><strong>Username:</strong> <?php echo e($username); ?></p>
<p><strong>Xabar:</strong></p>
<pre><?php echo e($text); ?></pre>
<?php /**PATH /home/jobresum/domains/jobresume.uz/public_html/bot/resources/views/emails/feedback_received.blade.php ENDPATH**/ ?>