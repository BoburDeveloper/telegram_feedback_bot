<?php

return [
    'edit'=>'Edit',
    'tbot_token'=>'T.Bot token',
    'tbot_name'=>'T.Bot name',
    'tbot_username'=>'T.Bot username',
    'my_tbots'=>'My Telegram Bots',
    'add_tbot'=>'Add T.Bot',
    'edit_tbot'=>'Edit T.Bot',
    'save'=>'Save',

];