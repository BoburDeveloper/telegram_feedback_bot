<?php

use App\Http\Middleware\BasicAuth;

return [
    'basic.auth' => BasicAuth::class,
];