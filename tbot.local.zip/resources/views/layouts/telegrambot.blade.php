<!DOCTYPE html>
<html lang="en">
<head>
    <title></title>
    <link rel="stylesheet" href="{{asset($asset_theme.'bootstrap-ui/css/bootstrap.min.css')}}"/>
    <script type="text/javascript" src="{{asset($asset_theme.'jquery/jquery.min.js')}}"></script>
</head>
<body>

@yield('content')

<footer></footer>
<script type="text/javascript" src="{{asset($asset_theme.'bootstrap-ui/js/bootstrap.min.js')}}"></script>
</body>
</html>