<h2>📥 New telegram message</h2>

<p><strong>Name:</strong> {{ $firstName }}</p>
<p><strong>Username:</strong> {{ $username }}</p>
<p><strong>Message:</strong></p>
<pre>{{ $text }}</pre>
